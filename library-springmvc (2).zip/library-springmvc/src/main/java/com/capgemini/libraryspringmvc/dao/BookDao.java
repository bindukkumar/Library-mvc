package com.capgemini.libraryspringmvc.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.libraryspringmvc.model.Book;

@Repository
public interface BookDao {
	public Book addBook(Book book);
	public boolean updateBook(int bookId);
	public boolean deleteBook(int bookId);
	public List<Book> getAllbook();
	public List<Book> SearchBook(int bookId);
	
}
