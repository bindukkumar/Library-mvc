package com.capgemini.libraryspringmvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.libraryspringmvc.model.Book;
import com.capgemini.libraryspringmvc.service.BookService;

@Controller
public class BookController {
	@Autowired
	private BookService bookservice;
	
	
	@RequestMapping("/")
	public ModelAndView home() {
	    List<Book> listBook = bookservice.getAllbook();
	    ModelAndView mav = new ModelAndView();
	    mav.addObject("listBook", listBook);
	    mav.setViewName("index");
	    return mav;
	}
	
	@RequestMapping("/new")
	public String newBookForm(Map<String,Object> model) {
		Book book = new Book();
		model.put("book", book);
		return "addBook";
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveBook(@ModelAttribute("book") Book book) {
		bookservice.addBook(book);
		//bookservice.updateBook(book.getBookId());
	    return "redirect:/";
	}
	
	
	@RequestMapping("/updateBook")
	public ModelAndView editBookForm(@RequestParam int id) {
		ModelAndView mav = new ModelAndView("updateBook");
		boolean book = bookservice.updateBook(id);
		mav.addObject("book", book);
		return mav;
	}

	@RequestMapping("/delete")
	public String deleteBookForm(@RequestParam int bookId) {
		bookservice.deleteBook(bookId);
	    return "redirect:/";       
	}
	@RequestMapping("/search")
	public ModelAndView search(@RequestParam int bookId) {
	    List<Book> result =bookservice.SearchBook(bookId);
	    ModelAndView mav = new ModelAndView("search");
	    mav.addObject("result", result);
	 
	    return mav;    
	}
	
	
	
	
	
	
	
	
}
