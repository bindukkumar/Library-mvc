package com.capgemini.libraryspringmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.libraryspringmvc.dao.BookDao;
import com.capgemini.libraryspringmvc.model.Book;
@Service
@Transactional
public class BookServiceImpl implements BookService {
	@Autowired
	BookDao bookdao;

	public Book addBook(Book book) {
		return bookdao.addBook(book);
	}

	public boolean updateBook(int bookId) {
		return bookdao.updateBook(bookId);
	}

	public boolean deleteBook(int bookId) {
		return bookdao.deleteBook(bookId);
	}

	public List<Book> getAllbook() {
		return bookdao.getAllbook();
	}

	public List<Book> SearchBook(int bookId) {
		return bookdao.SearchBook(bookId);
	}

}
