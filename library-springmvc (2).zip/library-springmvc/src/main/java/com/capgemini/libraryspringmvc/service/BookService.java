package com.capgemini.libraryspringmvc.service;

import java.util.List;

import com.capgemini.libraryspringmvc.model.Book;

public interface BookService {
	public Book addBook(Book book);

	public boolean updateBook(int bookId );

	public boolean deleteBook(int bookId);

	public List<Book> getAllbook();

	public List<Book> SearchBook(int bookId);
}
