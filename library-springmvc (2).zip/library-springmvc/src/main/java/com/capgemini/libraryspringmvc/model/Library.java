package com.capgemini.libraryspringmvc.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Library")
public class Library {
	@Id
	@Column
	private int lId;
	@Column
	private int lName;

	public Library() {
	}

	public Library(int lId, int lName) {
		super();
		this.lId = lId;
		this.lName = lName;
	}

	@OneToMany(mappedBy = "library" )
	private List<Book> books;

	public int getlId() {
		return lId;
	}

	public void setlId(int lId) {
		this.lId = lId;
	}

	public int getlName() {
		return lName;
	}

	public void setlName(int lName) {
		this.lName = lName;
	}

}
